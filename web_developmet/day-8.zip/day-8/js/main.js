//var isAble = true;

// console.log(10 + "15"); // output --> 1015

// console.log(10 - "7"); // output --> 3 ( 1. bug of javascript ) 

// console.log("hey " + "there");

// console.log(" " + 0);


// console.log("hey" - "there"); // NaN == > Not a Number ( 2. bug of javascript)

// console.log(true - false); // true = 1 , false = 0 ; ans = 1 - 0 = 1

// console.log(true + true); // 2 

// null and undefined

// var age = null;

// console.log(age);

// var myname;
// console.log(myname); // undefined

// console.log(typeof(age)); // null

// NaN

// var name = window.prompt("Enter your name ");

// var number = window.prompt("Enter your phone number ");

// if (isNaN(number)) {
//     document.write("hey Mr. " + name + " write your correct phone number ");
// }

// else{
//     document.write("hey Mr. "+name+" welcome to TEG .")
// }

// console.log(NaN == NaN); //false

// console.log(isNaN(NaN)); //true 

// console.log(Number.isNaN(NaN)); //true

// var num1 = 5;

// var num2 = 5.0;

// console.log(num1 == num2);

// console.log(num1 === num2);

//console.log(`numbers are equal or not + ${num1 == num2}`);

// control statement

// var name = "Suvadeep";

// if (name === "Suvadeep" ) {
//     console.log("welcome");
// }
// else{
//     console.log("not welcome");
// }

// switch case

// var option = window.prompt("choose");

// switch (option) {
//     case "1":
//         document.write("this is option 1");
//         break;
//     case "2":
//         document.write("this is option 2");
//         break;
//     case "3":
//         document.write("this is option 3");
//         break;
//     case "4":
//         document.write("this is option 4");
//         break;
//     default:
//         document.write("nothing !!");
//         break;
// }

// window.alert("Thanks for your submission")

const var1 = 5; // constant 


console.log(var1);

































